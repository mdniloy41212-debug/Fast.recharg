FAST RECHARGE — API-সংযুক্ত অ্যাপের সোর্স প্রজেক্ট

ফাইল:
- public/customer.html : কাস্টমার সাইন-আপ/লগইন, প্যাকেজ, অর্ডার ও অর্ডার ইতিহাস
- public/admin.html : আলাদা অ্যাডমিন লগইন, প্যাকেজ ম্যানেজমেন্ট, অর্ডার স্ট্যাটাস
- server.js : API সার্ভার, JWT লগইন, পাসওয়ার্ড হ্যাশিং, SQLite ডেটাবেস
- .env.example : নিজের গোপন লগইন ও সার্ভার সেটিংসের নমুনা

চালানোর জন্য:
1. Node.js 20 বা তার পরের সংস্করণ ইনস্টল করুন।
2. এই ফোল্ডারে terminal খুলে `npm install` চালান।
3. `.env.example` কপি করে `.env` বানান।
4. JWT_SECRET-এ অন্তত ৩২ অক্ষরের random secret দিন; ADMIN_USERNAME ও ADMIN_PASSWORD নিজের মতো সেট করুন। আসল পাসওয়ার্ড কাউকে পাঠাবেন না।
5. `npm start` চালান।
6. একই সার্ভারে Customer: `/` এবং Admin: `/admin.html` খুলুন।

সীমাবদ্ধতা ও নিরাপত্তা:
- সোর্স কোড প্রস্তুত, কিন্তু এটি এখনো কোনো পাবলিক সার্ভারে deploy করা হয়নি। তাই আলাদা ফোন থেকে একই ডেটাবেসে ঢুকতে হলে এই সার্ভারকে HTTPS-সহ অনলাইনে host করতে হবে।
- Admin এবং Customer একই server API-তে কথা বলে; অনলাইনে deploy না করা পর্যন্ত সংযোগটি শুধু লোকাল।
- SQLite ফাইল সার্ভারের ডিস্কে থাকে। Hosting-এ persistent disk/backup নিশ্চিত করতে হবে।
- বাস্তব recharge/payment supplier API যুক্ত করা হয়নি। অর্ডারের status শুধু admin বদলায়; Completed মানেই supplier-এ recharge হয়েছে এমন নয়।
- Production ব্যবহারের আগে security review, database backup, HTTPS, environment secret management, এবং বাস্তব supplier integration আবশ্যক।
